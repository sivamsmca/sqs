package com.demo.model;

public class SQSQueueAttributeModel {
	
	private String queueURL;
	private String messageBody;
	private String delaySeconds;
	public String getQueueURL() {
		return queueURL;
	}
	public void setQueueURL(String queueURL) {
		this.queueURL = queueURL;
	}
	public String getMessageBody() {
		return messageBody;
	}
	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}
	public String getDelaySeconds() {
		return delaySeconds;
	}
	public void setDelaySeconds(String delaySeconds) {
		this.delaySeconds = delaySeconds;
	}
	
	
	

}
