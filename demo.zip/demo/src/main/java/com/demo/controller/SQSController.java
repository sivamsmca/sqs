package com.demo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.AmazonSQSException;
import com.amazonaws.services.sqs.model.CreateQueueRequest;
import com.amazonaws.services.sqs.model.CreateQueueResult;
import com.amazonaws.services.sqs.model.ListQueuesResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.demo.model.SQSQueueAttributeModel;

@RestController
public class SQSController {


    
    @Value("${cloud.aws.credentials.access-key}")
    private String accessKey;

    @Value("${cloud.aws.credentials.secret-key}")
    private String secretKey;
    
    private AmazonSQS sqs =null;
    
    @PostConstruct
    public void init()
    {
    	BasicAWSCredentials awsCredentials = new BasicAWSCredentials(this.accessKey, this.secretKey);
    	sqs = AmazonSQSClientBuilder
                .standard().withRegion(Regions.US_EAST_2)
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .build();
    	System.out.println("initiliazed");
    }

       
    @RequestMapping("/createSQSQueue/{queueName}")
    public String createQueue(@PathVariable String queueName) {
        System.out.println("Queue Messages: " + queueName);
        

        // Creating a Queue
        CreateQueueRequest createRequest = new CreateQueueRequest(queueName)
                .addAttributesEntry("DelaySeconds", "60")
                .addAttributesEntry("MessageRetentionPeriod", "86400");
        createRequest.setSdkClientExecutionTimeout(20000000);
        

        try {
            CreateQueueResult response=sqs.createQueue(createRequest);
            if(response!=null)
            	return response.getQueueUrl();
            
        } catch (AmazonSQSException e) {
            if (!e.getErrorCode().equals("QueueAlreadyExists")) {
                throw e;
            }
        }
        return "Unable to create Queue Please contact admin";
    }
    
    @PostMapping("sendQueueMessage")
    public String sendQueueMessage(@RequestBody SQSQueueAttributeModel model) {
        System.out.println("Enter sendQueueMessage: ");
        
        Validate.notNull(model, "Must be provide request body");
        
        SendMessageRequest sendMessageStandardQueue = new SendMessageRequest()
        		  .withQueueUrl(model.getQueueURL())
        		  .withMessageBody(model.getMessageBody())
        		  .withDelaySeconds(model.getDelaySeconds().isBlank()? 30 : Integer.parseInt(model.getDelaySeconds()))
        		  .withMessageAttributes(null);

        		sqs.sendMessage(sendMessageStandardQueue);
        return "Successfully populate the message";
    }
    
    @GetMapping("getQueueList")
    public List<String> getQueueList() {
        System.out.println("Enter getQueueList");
        List<String> queueList=new ArrayList<>();

        ListQueuesResult lq_result = sqs.listQueues();
        System.out.println("Your SQS Queue URLs:");
        for (String url : lq_result.getQueueUrls()) {
        	queueList.add(url);
           
        }
        System.out.println("Queue List:\t"+queueList);
        return queueList;
       
    }


}