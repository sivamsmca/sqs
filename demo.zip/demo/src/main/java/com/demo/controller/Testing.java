package com.demo.controller;

public class Testing {
	
	public static void main(String[] args) {
		
		int a[]=new int[]{1,2,3};
		int tempArray[]=new int[20];
		for (int i=0;i<a.length;i++)
		{
			for(int j=i;j<=i;j++)
			{
				tempArray[i--]=j;
			}
		}
		
		
		for(int t:tempArray)
			System.out.println(t);
	}

}
